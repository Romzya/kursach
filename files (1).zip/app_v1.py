#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ВЕРСИЯ 1 — Простое Flask-приложение
Система электронных платежей
Запуск: python3 app_v1.py
Открыть: http://127.0.0.1:5001
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from flask import Flask, render_template_string, request, redirect, url_for, flash
import sqlite3
from datetime import datetime
from db import get_conn, log_event, init_db

app = Flask(__name__)
app.secret_key = "payments_v1_secret"

# ─── HTML-шаблон (единый для всего приложения) ───────────────────────────────
BASE_HTML = """<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>💳 Электронные платежи — Версия 1</title>
<style>
  body { font-family: Arial, sans-serif; background:#f0f2f5; margin:0; padding:0; }
  header { background:#1a237e; color:#fff; padding:14px 24px; }
  header h1 { margin:0; font-size:20px; }
  nav { background:#283593; padding:8px 24px; display:flex; gap:12px; flex-wrap:wrap; }
  nav a { color:#fff; text-decoration:none; padding:6px 14px;
          border-radius:4px; font-size:14px; background:rgba(255,255,255,.15); }
  nav a:hover { background:rgba(255,255,255,.3); }
  .container { max-width:1000px; margin:24px auto; padding:0 16px; }
  .card { background:#fff; border-radius:8px; box-shadow:0 1px 4px rgba(0,0,0,.12);
          padding:20px; margin-bottom:20px; }
  h2 { margin-top:0; color:#1a237e; font-size:18px; }
  table { width:100%; border-collapse:collapse; font-size:14px; }
  th { background:#e8eaf6; text-align:left; padding:8px 10px; }
  td { padding:7px 10px; border-bottom:1px solid #eee; }
  tr:hover td { background:#f5f5f5; }
  .badge { padding:2px 8px; border-radius:10px; font-size:12px; font-weight:bold; }
  .badge-active,.badge-completed { background:#c8e6c9; color:#2e7d32; }
  .badge-blocked,.badge-failed   { background:#ffcdd2; color:#c62828; }
  .badge-pending  { background:#fff9c4; color:#f57f17; }
  .badge-reversed { background:#e1bee7; color:#6a1b9a; }
  form label { display:block; margin-bottom:4px; font-size:14px; color:#555; }
  form input, form select { width:100%; padding:8px; margin-bottom:12px;
    border:1px solid #ccc; border-radius:4px; box-sizing:border-box; font-size:14px; }
  .btn { padding:8px 20px; border:none; border-radius:4px; cursor:pointer;
         font-size:14px; font-weight:bold; }
  .btn-primary { background:#1a237e; color:#fff; }
  .btn-danger  { background:#c62828; color:#fff; }
  .btn-success { background:#2e7d32; color:#fff; }
  .flash-ok  { background:#c8e6c9; color:#2e7d32; padding:10px; border-radius:4px; margin-bottom:12px; }
  .flash-err { background:#ffcdd2; color:#c62828; padding:10px; border-radius:4px; margin-bottom:12px; }
  .stat-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:12px; }
  .stat-box  { background:#e8eaf6; border-radius:8px; padding:14px; text-align:center; }
  .stat-box .val { font-size:24px; font-weight:bold; color:#1a237e; }
  .stat-box .lbl { font-size:12px; color:#555; margin-top:4px; }
</style>
</head>
<body>
<header><h1>💳 Система электронных платежей &nbsp;|&nbsp; <small>Версия 1 — Базовая</small></h1></header>
<nav>
  <a href="/">🏠 Главная</a>
  <a href="/clients">👥 Клиенты</a>
  <a href="/accounts">🏦 Счета</a>
  <a href="/transactions">🔄 Транзакции</a>
  <a href="/reports">📊 Отчёты</a>
</nav>
<div class="container">
{% with messages = get_flashed_messages(with_categories=True) %}
  {% for cat, msg in messages %}
    <div class="{{ 'flash-ok' if cat=='ok' else 'flash-err' }}">{{ msg }}</div>
  {% endfor %}
{% endwith %}
{{ content }}
</div>
</body></html>"""

def render(content, **kw):
    from flask import render_template_string
    return render_template_string(BASE_HTML, content=content, **kw)


def badge(status):
    return f'<span class="badge badge-{status}">{status}</span>'


# ─── ГЛАВНАЯ ─────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    with get_conn() as conn:
        n_clients  = conn.execute("SELECT COUNT(*) FROM clients").fetchone()[0]
        n_accounts = conn.execute("SELECT COUNT(*) FROM accounts WHERE is_active=1").fetchone()[0]
        n_tx       = conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        n_ok       = conn.execute("SELECT COUNT(*) FROM transactions WHERE status='completed'").fetchone()[0]
        total_rub  = conn.execute("SELECT COALESCE(SUM(balance),0) FROM accounts WHERE currency='RUB' AND is_active=1").fetchone()[0]
    html = f"""
    <div class="card">
      <h2>Обзор системы</h2>
      <div class="stat-grid">
        <div class="stat-box"><div class="val">{n_clients}</div><div class="lbl">Клиентов</div></div>
        <div class="stat-box"><div class="val">{n_accounts}</div><div class="lbl">Активных счетов</div></div>
        <div class="stat-box"><div class="val">{n_tx}</div><div class="lbl">Транзакций</div></div>
        <div class="stat-box"><div class="val">{n_ok}</div><div class="lbl">Успешных</div></div>
        <div class="stat-box"><div class="val">{total_rub:,.0f} ₽</div><div class="lbl">Сумма балансов RUB</div></div>
      </div>
    </div>
    """
    return render(html)


# ─── КЛИЕНТЫ ─────────────────────────────────────────────────────────────────
@app.route("/clients")
def clients():
    with get_conn() as conn:
        rows = conn.execute("SELECT id,full_name,email,phone,status,created_at FROM clients ORDER BY id").fetchall()
    rows_html = "".join(
        f"<tr><td>{r['id']}</td><td>{r['full_name']}</td><td>{r['email']}</td>"
        f"<td>{r['phone'] or '—'}</td><td>{badge(r['status'])}</td><td>{r['created_at']}</td></tr>"
        for r in rows
    )
    html = f"""
    <div class="card">
      <h2>👥 Клиенты &nbsp; <a href="/clients/add" class="btn btn-primary" style="font-size:13px">+ Добавить</a></h2>
      <table><tr><th>ID</th><th>ФИО</th><th>Email</th><th>Телефон</th><th>Статус</th><th>Создан</th></tr>
      {rows_html}</table>
    </div>"""
    return render(html)


@app.route("/clients/add", methods=["GET","POST"])
def client_add():
    if request.method == "POST":
        name  = request.form.get("name","").strip()
        email = request.form.get("email","").strip()
        phone = request.form.get("phone","").strip() or None
        if not name or not email:
            flash("ФИО и email обязательны", "err")
            return redirect(url_for("client_add"))
        try:
            with get_conn() as conn:
                conn.execute("INSERT INTO clients(full_name,email,phone) VALUES(?,?,?)", (name,email,phone))
            log_event("CLIENT_ADD", f"Добавлен: {name}")
            flash(f"Клиент «{name}» добавлен", "ok")
            return redirect(url_for("clients"))
        except Exception as e:
            flash(f"Ошибка: {e}", "err")
            return redirect(url_for("client_add"))
    html = """
    <div class="card" style="max-width:480px">
      <h2>Новый клиент</h2>
      <form method="post">
        <label>ФИО</label><input name="name" required>
        <label>Email</label><input name="email" type="email" required>
        <label>Телефон</label><input name="phone">
        <button class="btn btn-primary">Добавить</button>
        &nbsp;<a href="/clients">Отмена</a>
      </form>
    </div>"""
    return render(html)


@app.route("/clients/<int:cid>/status", methods=["POST"])
def client_status(cid):
    new_status = request.form.get("status")
    if new_status not in ("active","blocked","pending"):
        flash("Неверный статус", "err")
    else:
        with get_conn() as conn:
            conn.execute("UPDATE clients SET status=? WHERE id=?", (new_status, cid))
        log_event("CLIENT_STATUS", f"Клиент #{cid} → {new_status}")
        flash("Статус обновлён", "ok")
    return redirect(url_for("clients"))


# ─── СЧЕТА ───────────────────────────────────────────────────────────────────
@app.route("/accounts")
def accounts():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT a.id,c.full_name,a.account_no,a.currency,a.balance,a.is_active "
            "FROM accounts a JOIN clients c ON c.id=a.client_id ORDER BY a.id"
        ).fetchall()
    rows_html = "".join(
        f"<tr><td>{r['id']}</td><td>{r['full_name']}</td><td>{r['account_no']}</td>"
        f"<td>{r['currency']}</td><td><b>{r['balance']:,.2f}</b></td>"
        f"<td>{'<span class=\"badge badge-active\">активен</span>' if r['is_active'] else '<span class=\"badge badge-failed\">закрыт</span>'}</td></tr>"
        for r in rows
    )
    html = f"""
    <div class="card">
      <h2>🏦 Счета &nbsp; <a href="/accounts/open" class="btn btn-success" style="font-size:13px">+ Открыть</a>
       &nbsp; <a href="/accounts/deposit" class="btn btn-primary" style="font-size:13px">⬇ Пополнить</a></h2>
      <table><tr><th>ID</th><th>Клиент</th><th>Номер</th><th>Валюта</th><th>Баланс</th><th>Статус</th></tr>
      {rows_html}</table>
    </div>"""
    return render(html)


@app.route("/accounts/open", methods=["GET","POST"])
def account_open():
    if request.method == "POST":
        cid      = request.form.get("client_id","").strip()
        currency = request.form.get("currency","RUB").strip().upper()
        if not cid:
            flash("Выберите клиента", "err")
            return redirect(url_for("account_open"))
        ts     = datetime.now().strftime("%Y%m%d%H%M%S")
        acc_no = f"ACC-{int(cid):04d}-{ts[-6:]}-{currency}"
        try:
            with get_conn() as conn:
                conn.execute("INSERT INTO accounts(client_id,account_no,currency) VALUES(?,?,?)", (cid,acc_no,currency))
            log_event("ACCOUNT_OPEN", f"Открыт {acc_no}")
            flash(f"Счёт {acc_no} открыт", "ok")
            return redirect(url_for("accounts"))
        except Exception as e:
            flash(f"Ошибка: {e}", "err")
    with get_conn() as conn:
        clients_list = conn.execute("SELECT id,full_name FROM clients WHERE status='active' ORDER BY full_name").fetchall()
    opts = "".join(f'<option value="{c["id"]}">{c["full_name"]}</option>' for c in clients_list)
    html = f"""
    <div class="card" style="max-width:480px">
      <h2>Открыть счёт</h2>
      <form method="post">
        <label>Клиент</label><select name="client_id">{opts}</select>
        <label>Валюта</label>
        <select name="currency"><option>RUB</option><option>USD</option><option>EUR</option></select>
        <button class="btn btn-success">Открыть</button>
        &nbsp;<a href="/accounts">Отмена</a>
      </form>
    </div>"""
    return render(html)


@app.route("/accounts/deposit", methods=["GET","POST"])
def account_deposit():
    if request.method == "POST":
        acc_id = request.form.get("acc_id","").strip()
        amount = request.form.get("amount","").strip()
        try:
            amount = float(amount)
            assert amount > 0
        except:
            flash("Введите корректную сумму", "err")
            return redirect(url_for("account_deposit"))
        with get_conn() as conn:
            acc = conn.execute("SELECT id,currency FROM accounts WHERE id=? AND is_active=1", (acc_id,)).fetchone()
            if not acc:
                flash("Счёт не найден", "err")
                return redirect(url_for("account_deposit"))
            conn.execute("UPDATE accounts SET balance=balance+? WHERE id=?", (amount, acc_id))
            conn.execute("INSERT INTO transactions(to_account_id,amount,type,status,description) VALUES(?,?,'deposit','completed','Пополнение счёта')", (acc_id, amount))
        log_event("DEPOSIT", f"Счёт #{acc_id} пополнен на {amount}")
        flash(f"Счёт пополнен на {amount:,.2f}", "ok")
        return redirect(url_for("accounts"))
    with get_conn() as conn:
        accs = conn.execute(
            "SELECT a.id, a.account_no, a.currency, c.full_name FROM accounts a "
            "JOIN clients c ON c.id=a.client_id WHERE a.is_active=1 ORDER BY a.id"
        ).fetchall()
    opts = "".join(f'<option value="{a["id"]}">[{a["id"]}] {a["account_no"]} — {a["full_name"]} ({a["currency"]})</option>' for a in accs)
    html = f"""
    <div class="card" style="max-width:480px">
      <h2>Пополнение счёта</h2>
      <form method="post">
        <label>Счёт</label><select name="acc_id">{opts}</select>
        <label>Сумма</label><input name="amount" type="number" step="0.01" min="0.01" required>
        <button class="btn btn-primary">Пополнить</button>
        &nbsp;<a href="/accounts">Отмена</a>
      </form>
    </div>"""
    return render(html)


# ─── ТРАНЗАКЦИИ ──────────────────────────────────────────────────────────────
@app.route("/transactions")
def transactions():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT t.id,t.type,t.amount,t.status,t.description,t.created_at,"
            " fa.account_no AS from_acc, ta.account_no AS to_acc "
            "FROM transactions t "
            "LEFT JOIN accounts fa ON fa.id=t.from_account_id "
            "LEFT JOIN accounts ta ON ta.id=t.to_account_id "
            "ORDER BY t.id DESC LIMIT 30"
        ).fetchall()
    rows_html = "".join(
        f"<tr><td>{r['id']}</td><td>{r['type']}</td>"
        f"<td>{r['from_acc'] or '—'}</td><td>{r['to_acc'] or '—'}</td>"
        f"<td><b>{r['amount']:,.2f}</b></td><td>{badge(r['status'])}</td>"
        f"<td>{r['description'] or '—'}</td><td>{r['created_at']}</td></tr>"
        for r in rows
    )
    html = f"""
    <div class="card">
      <h2>🔄 Транзакции &nbsp;
        <a href="/transactions/transfer" class="btn btn-primary" style="font-size:13px">→ Перевод</a>
        &nbsp;<a href="/transactions/withdrawal" class="btn btn-danger" style="font-size:13px">↑ Снятие</a>
      </h2>
      <table>
        <tr><th>ID</th><th>Тип</th><th>Отправитель</th><th>Получатель</th>
            <th>Сумма</th><th>Статус</th><th>Описание</th><th>Дата</th></tr>
        {rows_html}
      </table>
    </div>"""
    return render(html)


@app.route("/transactions/transfer", methods=["GET","POST"])
def transfer():
    if request.method == "POST":
        from_id = request.form.get("from_id","").strip()
        to_id   = request.form.get("to_id","").strip()
        amount  = request.form.get("amount","").strip()
        desc    = request.form.get("desc","Перевод").strip()
        try:
            amount = float(amount)
            assert amount > 0
        except:
            flash("Некорректная сумма", "err")
            return redirect(url_for("transfer"))
        if from_id == to_id:
            flash("Нельзя переводить на тот же счёт", "err")
            return redirect(url_for("transfer"))
        with get_conn() as conn:
            src = conn.execute("SELECT balance,currency FROM accounts WHERE id=? AND is_active=1", (from_id,)).fetchone()
            dst = conn.execute("SELECT id FROM accounts WHERE id=? AND is_active=1", (to_id,)).fetchone()
            if not src:
                flash("Счёт отправителя не найден", "err")
                return redirect(url_for("transfer"))
            if not dst:
                flash("Счёт получателя не найден", "err")
                return redirect(url_for("transfer"))
            if src["balance"] < amount:
                conn.execute(
                    "INSERT INTO transactions(from_account_id,to_account_id,amount,type,status,description)"
                    " VALUES(?,?,?,'transfer','failed',?)", (from_id,to_id,amount,desc)
                )
                flash(f"Недостаточно средств (баланс: {src['balance']:,.2f} {src['currency']})", "err")
                return redirect(url_for("transfer"))
            conn.execute("UPDATE accounts SET balance=balance-? WHERE id=?", (amount, from_id))
            conn.execute("UPDATE accounts SET balance=balance+? WHERE id=?", (amount, to_id))
            conn.execute(
                "INSERT INTO transactions(from_account_id,to_account_id,amount,type,status,description)"
                " VALUES(?,?,?,'transfer','completed',?)", (from_id,to_id,amount,desc)
            )
        log_event("TRANSFER", f"{amount} со счёта #{from_id} на #{to_id}")
        flash(f"Перевод {amount:,.2f} выполнен успешно!", "ok")
        return redirect(url_for("transactions"))
    with get_conn() as conn:
        accs = conn.execute(
            "SELECT a.id, a.account_no, a.currency, a.balance, c.full_name FROM accounts a "
            "JOIN clients c ON c.id=a.client_id WHERE a.is_active=1 ORDER BY a.id"
        ).fetchall()
    opts = "".join(
        f'<option value="{a["id"]}">[{a["id"]}] {a["account_no"]} — {a["full_name"]} ({a["balance"]:,.2f} {a["currency"]})</option>'
        for a in accs
    )
    html = f"""
    <div class="card" style="max-width:560px">
      <h2>Перевод между счетами</h2>
      <form method="post">
        <label>Счёт отправителя</label><select name="from_id">{opts}</select>
        <label>Счёт получателя</label><select name="to_id">{opts}</select>
        <label>Сумма</label><input name="amount" type="number" step="0.01" min="0.01" required>
        <label>Назначение</label><input name="desc" value="Перевод">
        <button class="btn btn-primary">Выполнить перевод</button>
        &nbsp;<a href="/transactions">Отмена</a>
      </form>
    </div>"""
    return render(html)


@app.route("/transactions/withdrawal", methods=["GET","POST"])
def withdrawal():
    if request.method == "POST":
        acc_id = request.form.get("acc_id","").strip()
        amount = request.form.get("amount","").strip()
        try:
            amount = float(amount)
            assert amount > 0
        except:
            flash("Некорректная сумма", "err")
            return redirect(url_for("withdrawal"))
        with get_conn() as conn:
            acc = conn.execute("SELECT balance,currency FROM accounts WHERE id=? AND is_active=1", (acc_id,)).fetchone()
            if not acc:
                flash("Счёт не найден", "err")
                return redirect(url_for("withdrawal"))
            if acc["balance"] < amount:
                flash(f"Недостаточно средств ({acc['balance']:,.2f} {acc['currency']})", "err")
                return redirect(url_for("withdrawal"))
            conn.execute("UPDATE accounts SET balance=balance-? WHERE id=?", (amount, acc_id))
            conn.execute(
                "INSERT INTO transactions(from_account_id,amount,type,status,description)"
                " VALUES(?,?,'withdrawal','completed','Снятие наличных')", (acc_id, amount)
            )
        log_event("WITHDRAWAL", f"Снятие {amount} со счёта #{acc_id}")
        flash(f"Снято {amount:,.2f}", "ok")
        return redirect(url_for("transactions"))
    with get_conn() as conn:
        accs = conn.execute(
            "SELECT a.id,a.account_no,a.currency,a.balance,c.full_name FROM accounts a "
            "JOIN clients c ON c.id=a.client_id WHERE a.is_active=1 ORDER BY a.id"
        ).fetchall()
    opts = "".join(
        f'<option value="{a["id"]}">[{a["id"]}] {a["account_no"]} — {a["full_name"]} ({a["balance"]:,.2f} {a["currency"]})</option>'
        for a in accs
    )
    html = f"""
    <div class="card" style="max-width:480px">
      <h2>Снятие средств</h2>
      <form method="post">
        <label>Счёт</label><select name="acc_id">{opts}</select>
        <label>Сумма</label><input name="amount" type="number" step="0.01" min="0.01" required>
        <button class="btn btn-danger">Снять</button>
        &nbsp;<a href="/transactions">Отмена</a>
      </form>
    </div>"""
    return render(html)


# ─── ОТЧЁТЫ ──────────────────────────────────────────────────────────────────
@app.route("/reports")
def reports():
    with get_conn() as conn:
        # Запрос 1: клиент с наибольшим объёмом переводов в этом году
        top_client = conn.execute("""
            SELECT c.full_name, c.email, SUM(t.amount) AS total_sent
            FROM transactions t
            JOIN accounts a ON a.id = t.from_account_id
            JOIN clients c  ON c.id = a.client_id
            WHERE t.type='transfer' AND t.status='completed'
              AND strftime('%Y', t.created_at) = strftime('%Y','now')
            GROUP BY c.id ORDER BY total_sent DESC LIMIT 1
        """).fetchone()

        # Запрос 2: все транзакции за сегодня
        today_tx = conn.execute("""
            SELECT t.id, t.type, t.amount, t.status, t.description, t.created_at,
                   fa.account_no AS from_acc, ta.account_no AS to_acc
            FROM transactions t
            LEFT JOIN accounts fa ON fa.id=t.from_account_id
            LEFT JOIN accounts ta ON ta.id=t.to_account_id
            WHERE date(t.created_at) = date('now') ORDER BY t.created_at DESC
        """).fetchall()

        # Запрос 3: самый популярный тариф в этом месяце
        top_tariff = conn.execute("""
            SELECT tr.name, tr.transfer_fee_pct, tr.min_fee, tr.max_daily_limit,
                   COUNT(t.id) AS usage_count
            FROM transactions t
            JOIN tariffs tr ON tr.id = t.tariff_id
            WHERE strftime('%Y-%m', t.created_at) = strftime('%Y-%m','now')
            GROUP BY tr.id ORDER BY usage_count DESC LIMIT 1
        """).fetchone()

        # Топ-5 счетов
        top_accounts = conn.execute(
            "SELECT a.account_no,c.full_name,a.currency,a.balance "
            "FROM accounts a JOIN clients c ON c.id=a.client_id "
            "WHERE a.is_active=1 ORDER BY a.balance DESC LIMIT 5"
        ).fetchall()

        # Статистика по типам
        tx_stats = conn.execute(
            "SELECT type, COUNT(*), COALESCE(SUM(amount),0) FROM transactions GROUP BY type"
        ).fetchall()

    # Запрос 1
    q1_html = ""
    if top_client:
        q1_html = f"""
        <tr><td>ФИО</td><td><b>{top_client['full_name']}</b></td></tr>
        <tr><td>Email</td><td>{top_client['email']}</td></tr>
        <tr><td>Сумма переводов</td><td><b>{top_client['total_sent']:,.2f} ₽</b></td></tr>
        """
    else:
        q1_html = "<tr><td colspan='2'>Нет данных за текущий год</td></tr>"

    # Запрос 2
    today_rows = "".join(
        f"<tr><td>{r['id']}</td><td>{r['type']}</td><td>{r['amount']:,.2f}</td>"
        f"<td>{badge(r['status'])}</td><td>{r['from_acc'] or '—'} → {r['to_acc'] or '—'}</td>"
        f"<td>{r['description'] or '—'}</td></tr>"
        for r in today_tx
    ) or "<tr><td colspan='6'>Транзакций за сегодня нет</td></tr>"

    # Запрос 3
    if top_tariff:
        q3_html = f"""
        <tr><td>Тариф</td><td><b>{top_tariff['name']}</b></td></tr>
        <tr><td>Использований</td><td>{top_tariff['usage_count']}</td></tr>
        <tr><td>Комиссия</td><td>{top_tariff['transfer_fee_pct']}% (мин. {top_tariff['min_fee']} ₽)</td></tr>
        <tr><td>Лимит/день</td><td>{top_tariff['max_daily_limit']:,.0f} ₽</td></tr>
        """
    else:
        q3_html = "<tr><td colspan='2'>Нет данных за текущий месяц</td></tr>"

    top_acc_rows = "".join(
        f"<tr><td>{i}</td><td>{r['full_name']}</td><td>{r['account_no']}</td>"
        f"<td>{r['balance']:,.2f} {r['currency']}</td></tr>"
        for i, r in enumerate(top_accounts, 1)
    )

    stat_rows = "".join(
        f"<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]:,.2f}</td></tr>"
        for r in tx_stats
    )

    html = f"""
    <div class="card">
      <h2>Запрос 1: Клиент с наибольшим объёмом переводов в этом году</h2>
      <table><tr><th>Поле</th><th>Значение</th></tr>{q1_html}</table>
    </div>
    <div class="card">
      <h2>Запрос 2: Все транзакции за сегодня</h2>
      <table>
        <tr><th>ID</th><th>Тип</th><th>Сумма</th><th>Статус</th><th>Счета</th><th>Описание</th></tr>
        {today_rows}
      </table>
    </div>
    <div class="card">
      <h2>Запрос 3: Самый популярный тариф в этом месяце</h2>
      <table><tr><th>Поле</th><th>Значение</th></tr>{q3_html}</table>
    </div>
    <div class="card">
      <h2>Топ-5 счетов по балансу</h2>
      <table><tr><th>#</th><th>Клиент</th><th>Счёт</th><th>Баланс</th></tr>
      {top_acc_rows}</table>
    </div>
    <div class="card">
      <h2>Статистика по типам транзакций</h2>
      <table><tr><th>Тип</th><th>Количество</th><th>Оборот (₽)</th></tr>
      {stat_rows}</table>
    </div>
    """
    return render(html)


if __name__ == "__main__":
    init_db()
    print("Версия 1 запущена: http://127.0.0.1:5001")
    app.run(debug=True, port=5001)
