#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ВЕРСИЯ 2 — Расширенное Flask-приложение
Система электронных платежей
Запуск: python3 app_v2.py
Открыть: http://127.0.0.1:5002
"""

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from flask import Flask, render_template_string, request, redirect, url_for, flash, jsonify
import sqlite3
from datetime import datetime
from db import get_conn, log_event, init_db

app = Flask(__name__)
app.secret_key = "payments_v2_secret_extended"

# ═══════════════════════════════════════════════════════════════
# БАЗОВЫЙ ШАБЛОН
# ═══════════════════════════════════════════════════════════════
BASE = """<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{% block title %}Платежи v2{% endblock %}</title>
<style>
:root {
  --primary:   #1565c0;
  --primary-d: #0d47a1;
  --accent:    #00acc1;
  --success:   #2e7d32;
  --danger:    #c62828;
  --warn:      #e65100;
  --bg:        #eceff1;
  --surface:   #ffffff;
  --border:    #cfd8dc;
  --text:      #263238;
  --muted:     #607d8b;
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;flex-direction:column}

/* ── sidebar layout ── */
.layout{display:flex;flex:1}
.sidebar{width:220px;min-height:100vh;background:var(--primary-d);color:#fff;flex-shrink:0;padding-top:0}
.sidebar-brand{padding:20px 16px;background:rgba(0,0,0,.2);border-bottom:1px solid rgba(255,255,255,.1)}
.sidebar-brand span{font-size:20px;font-weight:700}
.sidebar-brand small{display:block;font-size:11px;opacity:.7;margin-top:2px}
.sidebar nav a{display:flex;align-items:center;gap:10px;padding:11px 18px;color:rgba(255,255,255,.85);text-decoration:none;font-size:14px;transition:.2s}
.sidebar nav a:hover,.sidebar nav a.active{background:rgba(255,255,255,.15);color:#fff}
.sidebar nav a .ico{width:20px;text-align:center}
.sidebar-section{padding:10px 18px 4px;font-size:11px;text-transform:uppercase;opacity:.5;letter-spacing:.08em}

.main{flex:1;display:flex;flex-direction:column;overflow:hidden}
.topbar{background:var(--surface);border-bottom:1px solid var(--border);padding:0 28px;height:56px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 1px 3px rgba(0,0,0,.07)}
.topbar h1{font-size:17px;font-weight:600;color:var(--primary)}
.topbar .badge-ver{background:var(--accent);color:#fff;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:bold}
.content{padding:28px;flex:1;overflow-y:auto}

/* ── cards ── */
.card{background:var(--surface);border-radius:10px;box-shadow:0 1px 4px rgba(0,0,0,.1);padding:22px;margin-bottom:22px}
.card-title{font-size:16px;font-weight:600;color:var(--primary);margin-bottom:16px;display:flex;align-items:center;gap:8px}
.card-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(175px,1fr));gap:14px;margin-bottom:22px}
.stat{background:var(--surface);border-radius:10px;padding:18px;box-shadow:0 1px 4px rgba(0,0,0,.1);border-left:4px solid var(--accent)}
.stat .val{font-size:28px;font-weight:700;color:var(--primary)}
.stat .lbl{font-size:12px;color:var(--muted);margin-top:4px}

/* ── tables ── */
.tbl-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:13.5px}
thead tr{background:#e3f2fd}
th{padding:9px 12px;text-align:left;font-weight:600;color:var(--primary);white-space:nowrap}
td{padding:8px 12px;border-bottom:1px solid #f0f4f8}
tbody tr:hover td{background:#f8fbff}

/* ── badges ── */
.badge{display:inline-flex;align-items:center;gap:4px;padding:2px 9px;border-radius:12px;font-size:12px;font-weight:600}
.badge-active,.badge-completed{background:#e8f5e9;color:#2e7d32}
.badge-blocked,.badge-failed  {background:#ffebee;color:#c62828}
.badge-pending  {background:#fff8e1;color:#e65100}
.badge-reversed {background:#f3e5f5;color:#6a1b9a}
.badge-transfer {background:#e3f2fd;color:#1565c0}
.badge-deposit  {background:#e8f5e9;color:#2e7d32}
.badge-withdrawal{background:#fff3e0;color:#e65100}
.badge-fee      {background:#fce4ec;color:#c62828}

/* ── forms ── */
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.form-group{margin-bottom:14px}
.form-group label{display:block;font-size:13px;color:var(--muted);margin-bottom:5px;font-weight:500}
.form-group input,.form-group select,.form-group textarea{
  width:100%;padding:9px 11px;border:1px solid var(--border);border-radius:6px;font-size:14px;
  background:#fff;outline:none;transition:.2s}
.form-group input:focus,.form-group select:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(21,101,192,.12)}

/* ── buttons ── */
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 18px;border:none;border-radius:6px;
     font-size:13.5px;font-weight:600;cursor:pointer;text-decoration:none;transition:.15s}
.btn-primary {background:var(--primary);color:#fff}
.btn-primary:hover{background:var(--primary-d)}
.btn-success {background:#388e3c;color:#fff}
.btn-success:hover{background:#2e7d32}
.btn-danger  {background:var(--danger);color:#fff}
.btn-danger:hover{background:#b71c1c}
.btn-outline {background:transparent;border:1.5px solid var(--border);color:var(--text)}
.btn-outline:hover{background:#f5f5f5}
.btn-sm{padding:5px 12px;font-size:12px}

/* ── alerts ── */
.alert{padding:11px 16px;border-radius:7px;margin-bottom:16px;font-size:14px;display:flex;align-items:center;gap:8px}
.alert-ok {background:#e8f5e9;color:#1b5e20;border:1px solid #a5d6a7}
.alert-err{background:#ffebee;color:#b71c1c;border:1px solid #ef9a9a}

/* ── progress bar ── */
.prog-bar{height:8px;border-radius:4px;background:#e0e0e0;overflow:hidden;margin:6px 0}
.prog-bar-fill{height:100%;border-radius:4px;background:linear-gradient(90deg,#43a047,#66bb6a)}

/* ── responsive ── */
@media(max-width:640px){
  .sidebar{display:none}
  .form-row{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="sidebar-brand">
      <span>💳 ЭлПлатежи</span>
      <small>Версия 2 — Расширенная</small>
    </div>
    <nav>
      <div class="sidebar-section">Обзор</div>
      <a href="/" class="{{ 'active' if request.endpoint=='index' else '' }}">
        <span class="ico">🏠</span> Главная
      </a>
      <div class="sidebar-section">Управление</div>
      <a href="/clients" class="{{ 'active' if 'client' in (request.endpoint or '') else '' }}">
        <span class="ico">👥</span> Клиенты
      </a>
      <a href="/accounts" class="{{ 'active' if 'account' in (request.endpoint or '') else '' }}">
        <span class="ico">🏦</span> Счета
      </a>
      <a href="/transactions" class="{{ 'active' if 'transaction' in (request.endpoint or '') or 'transfer' in (request.endpoint or '') or 'withdrawal' in (request.endpoint or '') else '' }}">
        <span class="ico">🔄</span> Транзакции
      </a>
      <a href="/tariffs" class="{{ 'active' if 'tariff' in (request.endpoint or '') else '' }}">
        <span class="ico">📋</span> Тарифы
      </a>
      <div class="sidebar-section">Аналитика</div>
      <a href="/reports" class="{{ 'active' if request.endpoint=='reports' else '' }}">
        <span class="ico">📊</span> Отчёты
      </a>
      <a href="/log" class="{{ 'active' if request.endpoint=='syslog' else '' }}">
        <span class="ico">📜</span> Журнал
      </a>
    </nav>
  </aside>
  <div class="main">
    <div class="topbar">
      <h1>{% block page_title %}Система электронных платежей{% endblock %}</h1>
      <span class="badge-ver">v2.0</span>
    </div>
    <div class="content">
      {% with messages = get_flashed_messages(with_categories=True) %}
        {% for cat, msg in messages %}
          <div class="alert alert-{{ 'ok' if cat=='ok' else 'err' }}">
            {{ '✅' if cat=='ok' else '❌' }} {{ msg }}
          </div>
        {% endfor %}
      {% endwith %}
      {% block content %}{% endblock %}
    </div>
  </div>
</div>
</body></html>"""


def render_page(template_string, **ctx):
    full = BASE.replace("{% block content %}{% endblock %}", "{% block content %}" + template_string + "{% endblock %}")
    return render_template_string(full, request=request, **ctx)


def badge(status):
    return f'<span class="badge badge-{status}">{status}</span>'


# ═══════════════════════════════════════════════════════════════
# ГЛАВНАЯ
# ═══════════════════════════════════════════════════════════════
@app.route("/")
def index():
    with get_conn() as conn:
        n_clients  = conn.execute("SELECT COUNT(*) FROM clients").fetchone()[0]
        n_active_c = conn.execute("SELECT COUNT(*) FROM clients WHERE status='active'").fetchone()[0]
        n_accounts = conn.execute("SELECT COUNT(*) FROM accounts WHERE is_active=1").fetchone()[0]
        n_tx       = conn.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]
        n_ok       = conn.execute("SELECT COUNT(*) FROM transactions WHERE status='completed'").fetchone()[0]
        n_fail     = conn.execute("SELECT COUNT(*) FROM transactions WHERE status='failed'").fetchone()[0]
        total_rub  = conn.execute("SELECT COALESCE(SUM(balance),0) FROM accounts WHERE currency='RUB' AND is_active=1").fetchone()[0]
        recent_tx  = conn.execute("""
            SELECT t.id, t.type, t.amount, t.status, t.created_at,
                   fa.account_no as from_acc, ta.account_no as to_acc
            FROM transactions t
            LEFT JOIN accounts fa ON fa.id=t.from_account_id
            LEFT JOIN accounts ta ON ta.id=t.to_account_id
            ORDER BY t.id DESC LIMIT 8
        """).fetchall()

    pct = round(n_ok / n_tx * 100, 1) if n_tx else 0
    recent_rows = "".join(
        f"<tr><td>{r['id']}</td><td>{badge(r['type'])}</td>"
        f"<td>{r['from_acc'] or '—'} → {r['to_acc'] or '—'}</td>"
        f"<td><b>{r['amount']:,.2f}</b></td><td>{badge(r['status'])}</td><td>{r['created_at']}</td></tr>"
        for r in recent_tx
    )

    content = f"""
    <div class="card-grid">
      <div class="stat"><div class="val">{n_clients}</div><div class="lbl">👥 Клиентов ({n_active_c} активных)</div></div>
      <div class="stat"><div class="val">{n_accounts}</div><div class="lbl">🏦 Активных счетов</div></div>
      <div class="stat"><div class="val">{n_tx}</div><div class="lbl">🔄 Всего транзакций</div></div>
      <div class="stat"><div class="val" style="color:#2e7d32">{n_ok}</div><div class="lbl">✅ Успешных</div></div>
      <div class="stat"><div class="val" style="color:#c62828">{n_fail}</div><div class="lbl">❌ Неуспешных</div></div>
      <div class="stat"><div class="val">{total_rub:,.0f} ₽</div><div class="lbl">💰 Баланс RUB</div></div>
    </div>

    <div class="card">
      <div class="card-title">📈 Успешность транзакций</div>
      <div style="display:flex;align-items:center;gap:12px">
        <div class="prog-bar" style="flex:1"><div class="prog-bar-fill" style="width:{pct}%"></div></div>
        <b style="font-size:20px;color:var(--primary)">{pct}%</b>
      </div>
      <small style="color:var(--muted)">{n_ok} успешных из {n_tx} всего</small>
    </div>

    <div class="card">
      <div class="card-title">🕐 Последние транзакции</div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>ID</th><th>Тип</th><th>Счета</th><th>Сумма</th><th>Статус</th><th>Дата</th></tr></thead>
          <tbody>{recent_rows}</tbody>
        </table>
      </div>
    </div>
    """
    return render_template_string(
        BASE.replace("{% block page_title %}Система электронных платежей{% endblock %}",
                     "{% block page_title %}Главная — Обзор системы{% endblock %}")
            .replace("{% block content %}{% endblock %}", "{% block content %}" + content + "{% endblock %}"),
        request=request
    )


# ═══════════════════════════════════════════════════════════════
# КЛИЕНТЫ
# ═══════════════════════════════════════════════════════════════
@app.route("/clients")
def clients():
    search = request.args.get("q","").strip()
    with get_conn() as conn:
        if search:
            rows = conn.execute(
                "SELECT id,full_name,email,phone,status,created_at FROM clients "
                "WHERE full_name LIKE ? OR email LIKE ? ORDER BY id",
                (f"%{search}%", f"%{search}%")
            ).fetchall()
        else:
            rows = conn.execute("SELECT id,full_name,email,phone,status,created_at FROM clients ORDER BY id").fetchall()

    table_rows = ""
    for r in rows:
        table_rows += f"""
        <tr>
          <td>{r['id']}</td><td><b>{r['full_name']}</b></td>
          <td>{r['email']}</td><td>{r['phone'] or '—'}</td>
          <td>{badge(r['status'])}</td><td>{r['created_at']}</td>
          <td>
            <form method="post" action="/clients/{r['id']}/status" style="display:inline">
              <select name="status" style="padding:3px 6px;font-size:12px;border-radius:4px;border:1px solid #ccc">
                <option {'selected' if r['status']=='active' else ''} value="active">active</option>
                <option {'selected' if r['status']=='blocked' else ''} value="blocked">blocked</option>
                <option {'selected' if r['status']=='pending' else ''} value="pending">pending</option>
              </select>
              <button class="btn btn-outline btn-sm" style="margin-left:4px">✓</button>
            </form>
          </td>
        </tr>"""

    content = f"""
    <div class="card">
      <div class="card-title">
        👥 Клиенты
        <a href="/clients/add" class="btn btn-primary btn-sm" style="margin-left:auto">+ Добавить</a>
      </div>
      <form method="get" style="display:flex;gap:10px;margin-bottom:16px">
        <input name="q" value="{search}" placeholder="Поиск по имени или email..." style="flex:1;padding:8px 12px;border:1px solid #ccc;border-radius:6px;font-size:13px">
        <button class="btn btn-outline btn-sm">🔍 Найти</button>
        {'<a href="/clients" class="btn btn-outline btn-sm">✕ Сброс</a>' if search else ''}
      </form>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>ID</th><th>ФИО</th><th>Email</th><th>Телефон</th><th>Статус</th><th>Создан</th><th>Действия</th></tr></thead>
          <tbody>{table_rows}</tbody>
        </table>
      </div>
    </div>"""
    return render_page(content)


@app.route("/clients/add", methods=["GET","POST"])
def client_add():
    if request.method == "POST":
        name  = request.form.get("name","").strip()
        email = request.form.get("email","").strip()
        phone = request.form.get("phone","").strip() or None
        if not name or not email:
            flash("ФИО и email обязательны", "err")
            return redirect(url_for("client_add"))
        try:
            with get_conn() as conn:
                conn.execute("INSERT INTO clients(full_name,email,phone) VALUES(?,?,?)", (name,email,phone))
            log_event("CLIENT_ADD", f"Добавлен: {name}")
            flash(f"Клиент «{name}» успешно добавлен", "ok")
            return redirect(url_for("clients"))
        except Exception as e:
            flash(f"Ошибка: {e}", "err")
    content = """
    <div class="card" style="max-width:520px">
      <div class="card-title">👤 Новый клиент</div>
      <form method="post">
        <div class="form-group"><label>ФИО *</label><input name="name" required placeholder="Иванов Иван Иванович"></div>
        <div class="form-group"><label>Email *</label><input name="email" type="email" required placeholder="ivanov@mail.ru"></div>
        <div class="form-group"><label>Телефон</label><input name="phone" placeholder="+7-900-000-0000"></div>
        <div style="display:flex;gap:10px">
          <button class="btn btn-primary">✅ Добавить клиента</button>
          <a href="/clients" class="btn btn-outline">Отмена</a>
        </div>
      </form>
    </div>"""
    return render_page(content)


@app.route("/clients/<int:cid>/status", methods=["POST"])
def client_status(cid):
    new_status = request.form.get("status")
    if new_status not in ("active","blocked","pending"):
        flash("Неверный статус", "err")
    else:
        with get_conn() as conn:
            conn.execute("UPDATE clients SET status=? WHERE id=?", (new_status, cid))
        log_event("CLIENT_STATUS", f"Клиент #{cid} → {new_status}")
        flash(f"Статус клиента #{cid} обновлён на «{new_status}»", "ok")
    return redirect(url_for("clients"))


# ═══════════════════════════════════════════════════════════════
# СЧЕТА
# ═══════════════════════════════════════════════════════════════
@app.route("/accounts")
def accounts():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT a.id,c.full_name,a.account_no,a.currency,a.balance,a.is_active "
            "FROM accounts a JOIN clients c ON c.id=a.client_id ORDER BY a.balance DESC"
        ).fetchall()

    table_rows = "".join(
        f"<tr><td>{r['id']}</td><td>{r['full_name']}</td><td><code>{r['account_no']}</code></td>"
        f"<td>{r['currency']}</td><td><b>{r['balance']:,.2f}</b></td>"
        f"<td>{'<span class=\"badge badge-active\">активен</span>' if r['is_active'] else '<span class=\"badge badge-failed\">закрыт</span>'}</td>"
        f"<td>{'<form method=\"post\" action=\"/accounts/'+str(r['id'])+'/close\"><button class=\"btn btn-danger btn-sm\" onclick=\"return confirm(\'Закрыть счёт?\')\" '+('disabled' if not r['is_active'] or r['balance']>0 else '')+'>Закрыть</button></form>' if r['is_active'] else '—'}</td></tr>"
        for r in rows
    )

    content = f"""
    <div class="card">
      <div class="card-title">
        🏦 Счета
        <a href="/accounts/open" class="btn btn-success btn-sm" style="margin-left:auto">+ Открыть счёт</a>
        <a href="/accounts/deposit" class="btn btn-primary btn-sm">⬇ Пополнить</a>
      </div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>ID</th><th>Клиент</th><th>Номер счёта</th><th>Валюта</th><th>Баланс</th><th>Статус</th><th></th></tr></thead>
          <tbody>{table_rows}</tbody>
        </table>
      </div>
    </div>"""
    return render_page(content)


@app.route("/accounts/open", methods=["GET","POST"])
def account_open():
    if request.method == "POST":
        cid      = request.form.get("client_id","").strip()
        currency = request.form.get("currency","RUB").strip().upper()
        if not cid:
            flash("Выберите клиента", "err")
            return redirect(url_for("account_open"))
        ts     = datetime.now().strftime("%Y%m%d%H%M%S")
        acc_no = f"ACC-{int(cid):04d}-{ts[-6:]}-{currency}"
        try:
            with get_conn() as conn:
                conn.execute("INSERT INTO accounts(client_id,account_no,currency) VALUES(?,?,?)", (cid, acc_no, currency))
            log_event("ACCOUNT_OPEN", f"Открыт {acc_no}")
            flash(f"Счёт {acc_no} успешно открыт", "ok")
            return redirect(url_for("accounts"))
        except Exception as e:
            flash(f"Ошибка: {e}", "err")
    with get_conn() as conn:
        clients_list = conn.execute("SELECT id,full_name FROM clients WHERE status='active' ORDER BY full_name").fetchall()
    opts = "".join(f'<option value="{c["id"]}">{c["full_name"]}</option>' for c in clients_list)
    content = f"""
    <div class="card" style="max-width:520px">
      <div class="card-title">🏦 Открыть новый счёт</div>
      <form method="post">
        <div class="form-group"><label>Клиент</label><select name="client_id">{opts}</select></div>
        <div class="form-group"><label>Валюта</label>
          <select name="currency">
            <option value="RUB">🇷🇺 RUB — Российский рубль</option>
            <option value="USD">🇺🇸 USD — Доллар США</option>
            <option value="EUR">🇪🇺 EUR — Евро</option>
          </select>
        </div>
        <div style="display:flex;gap:10px">
          <button class="btn btn-success">✅ Открыть счёт</button>
          <a href="/accounts" class="btn btn-outline">Отмена</a>
        </div>
      </form>
    </div>"""
    return render_page(content)


@app.route("/accounts/deposit", methods=["GET","POST"])
def account_deposit():
    if request.method == "POST":
        acc_id = request.form.get("acc_id","").strip()
        amount = request.form.get("amount","").strip()
        try:
            amount = float(amount)
            assert amount > 0
        except:
            flash("Введите корректную сумму", "err")
            return redirect(url_for("account_deposit"))
        with get_conn() as conn:
            acc = conn.execute("SELECT id,currency FROM accounts WHERE id=? AND is_active=1", (acc_id,)).fetchone()
            if not acc:
                flash("Счёт не найден", "err")
                return redirect(url_for("account_deposit"))
            conn.execute("UPDATE accounts SET balance=balance+? WHERE id=?", (amount, acc_id))
            conn.execute("INSERT INTO transactions(to_account_id,amount,type,status,description) VALUES(?,?,'deposit','completed','Пополнение счёта')", (acc_id, amount))
        log_event("DEPOSIT", f"Счёт #{acc_id} +{amount}")
        flash(f"Счёт пополнен на {amount:,.2f}", "ok")
        return redirect(url_for("accounts"))
    with get_conn() as conn:
        accs = conn.execute(
            "SELECT a.id,a.account_no,a.currency,a.balance,c.full_name FROM accounts a "
            "JOIN clients c ON c.id=a.client_id WHERE a.is_active=1 ORDER BY a.id"
        ).fetchall()
    opts = "".join(
        f'<option value="{a["id"]}">[{a["id"]}] {a["account_no"]} — {a["full_name"]} ({a["balance"]:,.2f} {a["currency"]})</option>'
        for a in accs
    )
    content = f"""
    <div class="card" style="max-width:520px">
      <div class="card-title">⬇ Пополнение счёта</div>
      <form method="post">
        <div class="form-group"><label>Счёт получателя</label><select name="acc_id">{opts}</select></div>
        <div class="form-group"><label>Сумма пополнения</label>
          <input name="amount" type="number" step="0.01" min="0.01" required placeholder="0.00">
        </div>
        <div style="display:flex;gap:10px">
          <button class="btn btn-primary">⬇ Пополнить</button>
          <a href="/accounts" class="btn btn-outline">Отмена</a>
        </div>
      </form>
    </div>"""
    return render_page(content)


@app.route("/accounts/<int:acc_id>/close", methods=["POST"])
def account_close(acc_id):
    with get_conn() as conn:
        acc = conn.execute("SELECT balance FROM accounts WHERE id=? AND is_active=1", (acc_id,)).fetchone()
        if not acc:
            flash("Счёт не найден или уже закрыт", "err")
        elif acc["balance"] > 0:
            flash(f"На счёте есть остаток {acc['balance']:,.2f}. Сначала выведите средства.", "err")
        else:
            conn.execute("UPDATE accounts SET is_active=0 WHERE id=?", (acc_id,))
            log_event("ACCOUNT_CLOSE", f"Счёт #{acc_id} закрыт")
            flash(f"Счёт #{acc_id} закрыт", "ok")
    return redirect(url_for("accounts"))


# ═══════════════════════════════════════════════════════════════
# ТРАНЗАКЦИИ
# ═══════════════════════════════════════════════════════════════
@app.route("/transactions")
def transactions():
    ftype   = request.args.get("type","")
    fstatus = request.args.get("status","")
    with get_conn() as conn:
        q = """SELECT t.id,t.type,t.amount,t.status,t.description,t.created_at,
                      fa.account_no AS from_acc, ta.account_no AS to_acc
               FROM transactions t
               LEFT JOIN accounts fa ON fa.id=t.from_account_id
               LEFT JOIN accounts ta ON ta.id=t.to_account_id
               WHERE 1=1"""
        params = []
        if ftype:   q += " AND t.type=?";   params.append(ftype)
        if fstatus: q += " AND t.status=?"; params.append(fstatus)
        q += " ORDER BY t.id DESC LIMIT 50"
        rows = conn.execute(q, params).fetchall()

    table_rows = "".join(
        f"<tr><td>{r['id']}</td><td>{badge(r['type'])}</td>"
        f"<td>{r['from_acc'] or '—'}</td><td>{r['to_acc'] or '—'}</td>"
        f"<td style='text-align:right'><b>{r['amount']:,.2f}</b></td>"
        f"<td>{badge(r['status'])}</td>"
        f"<td>{r['description'] or '—'}</td><td>{r['created_at']}</td></tr>"
        for r in rows
    )

    def sel(val, cur): return "selected" if val == cur else ""
    content = f"""
    <div class="card">
      <div class="card-title">
        🔄 Транзакции
        <a href="/transactions/transfer" class="btn btn-primary btn-sm" style="margin-left:auto">→ Перевод</a>
        <a href="/transactions/withdrawal" class="btn btn-danger btn-sm">↑ Снятие</a>
      </div>
      <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;align-items:flex-end">
        <div>
          <label style="font-size:12px;color:var(--muted)">Тип</label><br>
          <select name="type" style="padding:7px 10px;border:1px solid #ccc;border-radius:6px;font-size:13px">
            <option value="" {sel('',ftype)}>Все типы</option>
            <option value="transfer" {sel('transfer',ftype)}>transfer</option>
            <option value="deposit" {sel('deposit',ftype)}>deposit</option>
            <option value="withdrawal" {sel('withdrawal',ftype)}>withdrawal</option>
            <option value="fee" {sel('fee',ftype)}>fee</option>
          </select>
        </div>
        <div>
          <label style="font-size:12px;color:var(--muted)">Статус</label><br>
          <select name="status" style="padding:7px 10px;border:1px solid #ccc;border-radius:6px;font-size:13px">
            <option value="" {sel('',fstatus)}>Все статусы</option>
            <option value="completed" {sel('completed',fstatus)}>completed</option>
            <option value="failed" {sel('failed',fstatus)}>failed</option>
            <option value="pending" {sel('pending',fstatus)}>pending</option>
            <option value="reversed" {sel('reversed',fstatus)}>reversed</option>
          </select>
        </div>
        <button class="btn btn-outline btn-sm">🔍 Фильтр</button>
        {'<a href="/transactions" class="btn btn-outline btn-sm">✕ Сброс</a>' if ftype or fstatus else ''}
      </form>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>ID</th><th>Тип</th><th>Отправитель</th><th>Получатель</th>
                     <th style="text-align:right">Сумма</th><th>Статус</th><th>Описание</th><th>Дата</th></tr></thead>
          <tbody>{table_rows}</tbody>
        </table>
      </div>
    </div>"""
    return render_page(content)


@app.route("/transactions/transfer", methods=["GET","POST"])
def transfer():
    if request.method == "POST":
        from_id  = request.form.get("from_id","").strip()
        to_id    = request.form.get("to_id","").strip()
        amount   = request.form.get("amount","").strip()
        desc     = request.form.get("desc","Перевод").strip()
        tariff_id = request.form.get("tariff_id","").strip() or None
        try:
            amount = float(amount)
            assert amount > 0
        except:
            flash("Некорректная сумма", "err")
            return redirect(url_for("transfer"))
        if from_id == to_id:
            flash("Нельзя переводить на тот же счёт", "err")
            return redirect(url_for("transfer"))
        with get_conn() as conn:
            src = conn.execute("SELECT balance,currency FROM accounts WHERE id=? AND is_active=1", (from_id,)).fetchone()
            dst = conn.execute("SELECT id FROM accounts WHERE id=? AND is_active=1", (to_id,)).fetchone()
            if not src:
                flash("Счёт отправителя не найден", "err"); return redirect(url_for("transfer"))
            if not dst:
                flash("Счёт получателя не найден", "err"); return redirect(url_for("transfer"))
            if src["balance"] < amount:
                conn.execute(
                    "INSERT INTO transactions(from_account_id,to_account_id,tariff_id,amount,type,status,description)"
                    " VALUES(?,?,?,?,'transfer','failed',?)", (from_id,to_id,tariff_id,amount,desc)
                )
                flash(f"Недостаточно средств (баланс: {src['balance']:,.2f} {src['currency']})", "err")
                return redirect(url_for("transfer"))
            # Расчёт комиссии
            fee = 0.0
            if tariff_id:
                tariff = conn.execute("SELECT transfer_fee_pct,min_fee FROM tariffs WHERE id=?", (tariff_id,)).fetchone()
                if tariff:
                    fee = max(tariff["min_fee"], amount * tariff["transfer_fee_pct"] / 100)
            if src["balance"] < amount + fee:
                flash(f"Недостаточно средств с учётом комиссии {fee:,.2f} ₽", "err")
                return redirect(url_for("transfer"))
            conn.execute("UPDATE accounts SET balance=balance-? WHERE id=?", (amount + fee, from_id))
            conn.execute("UPDATE accounts SET balance=balance+? WHERE id=?", (amount, to_id))
            conn.execute(
                "INSERT INTO transactions(from_account_id,to_account_id,tariff_id,amount,type,status,description)"
                " VALUES(?,?,?,?,'transfer','completed',?)", (from_id,to_id,tariff_id,amount,desc)
            )
            if fee > 0:
                conn.execute(
                    "INSERT INTO transactions(from_account_id,tariff_id,amount,type,status,description)"
                    " VALUES(?,?,?,'fee','completed','Комиссия за перевод')", (from_id,tariff_id,fee)
                )
        log_event("TRANSFER", f"{amount} #{from_id}→#{to_id}, комиссия {fee}")
        flash(f"Перевод {amount:,.2f} выполнен! Комиссия: {fee:,.2f}", "ok")
        return redirect(url_for("transactions"))

    with get_conn() as conn:
        accs = conn.execute(
            "SELECT a.id,a.account_no,a.currency,a.balance,c.full_name FROM accounts a "
            "JOIN clients c ON c.id=a.client_id WHERE a.is_active=1 ORDER BY a.id"
        ).fetchall()
        tariffs = conn.execute("SELECT id,name,transfer_fee_pct,min_fee FROM tariffs WHERE is_active=1").fetchall()

    opts = "".join(
        f'<option value="{a["id"]}">[{a["id"]}] {a["account_no"]} — {a["full_name"]} ({a["balance"]:,.2f} {a["currency"]})</option>'
        for a in accs
    )
    tariff_opts = '<option value="">— без тарифа —</option>' + "".join(
        f'<option value="{t["id"]}">{t["name"]} ({t["transfer_fee_pct"]}%, мин. {t["min_fee"]} ₽)</option>'
        for t in tariffs
    )

    content = f"""
    <div class="card" style="max-width:600px">
      <div class="card-title">→ Перевод между счетами</div>
      <form method="post">
        <div class="form-row">
          <div class="form-group"><label>Счёт отправителя</label><select name="from_id">{opts}</select></div>
          <div class="form-group"><label>Счёт получателя</label><select name="to_id">{opts}</select></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Сумма</label>
            <input name="amount" type="number" step="0.01" min="0.01" required placeholder="0.00">
          </div>
          <div class="form-group"><label>Тариф</label><select name="tariff_id">{tariff_opts}</select></div>
        </div>
        <div class="form-group"><label>Назначение платежа</label>
          <input name="desc" value="Перевод" placeholder="Назначение платежа">
        </div>
        <div style="display:flex;gap:10px">
          <button class="btn btn-primary">✅ Выполнить перевод</button>
          <a href="/transactions" class="btn btn-outline">Отмена</a>
        </div>
      </form>
    </div>"""
    return render_page(content)


@app.route("/transactions/withdrawal", methods=["GET","POST"])
def withdrawal():
    if request.method == "POST":
        acc_id = request.form.get("acc_id","").strip()
        amount = request.form.get("amount","").strip()
        try:
            amount = float(amount)
            assert amount > 0
        except:
            flash("Некорректная сумма", "err")
            return redirect(url_for("withdrawal"))
        with get_conn() as conn:
            acc = conn.execute("SELECT balance,currency FROM accounts WHERE id=? AND is_active=1", (acc_id,)).fetchone()
            if not acc:
                flash("Счёт не найден", "err"); return redirect(url_for("withdrawal"))
            if acc["balance"] < amount:
                flash(f"Недостаточно средств ({acc['balance']:,.2f} {acc['currency']})", "err")
                return redirect(url_for("withdrawal"))
            conn.execute("UPDATE accounts SET balance=balance-? WHERE id=?", (amount, acc_id))
            conn.execute(
                "INSERT INTO transactions(from_account_id,amount,type,status,description)"
                " VALUES(?,?,'withdrawal','completed','Снятие наличных')", (acc_id, amount)
            )
        log_event("WITHDRAWAL", f"Снятие {amount} #{acc_id}")
        flash(f"Снято {amount:,.2f}", "ok")
        return redirect(url_for("transactions"))

    with get_conn() as conn:
        accs = conn.execute(
            "SELECT a.id,a.account_no,a.currency,a.balance,c.full_name FROM accounts a "
            "JOIN clients c ON c.id=a.client_id WHERE a.is_active=1 ORDER BY a.id"
        ).fetchall()
    opts = "".join(
        f'<option value="{a["id"]}">[{a["id"]}] {a["account_no"]} — {a["full_name"]} ({a["balance"]:,.2f} {a["currency"]})</option>'
        for a in accs
    )
    content = f"""
    <div class="card" style="max-width:520px">
      <div class="card-title">↑ Снятие средств</div>
      <form method="post">
        <div class="form-group"><label>Счёт</label><select name="acc_id">{opts}</select></div>
        <div class="form-group"><label>Сумма снятия</label>
          <input name="amount" type="number" step="0.01" min="0.01" required placeholder="0.00">
        </div>
        <div style="display:flex;gap:10px">
          <button class="btn btn-danger">↑ Снять средства</button>
          <a href="/transactions" class="btn btn-outline">Отмена</a>
        </div>
      </form>
    </div>"""
    return render_page(content)


# ═══════════════════════════════════════════════════════════════
# ТАРИФЫ
# ═══════════════════════════════════════════════════════════════
@app.route("/tariffs")
def tariffs():
    with get_conn() as conn:
        rows = conn.execute("SELECT id,name,transfer_fee_pct,min_fee,max_daily_limit,is_active FROM tariffs").fetchall()
    table_rows = "".join(
        f"<tr><td>{r['id']}</td><td><b>{r['name']}</b></td>"
        f"<td>{r['transfer_fee_pct']}%</td><td>{r['min_fee']:,.2f} ₽</td>"
        f"<td>{r['max_daily_limit']:,.0f} ₽</td>"
        f"<td>{'<span class=\"badge badge-active\">активен</span>' if r['is_active'] else '<span class=\"badge badge-failed\">неактивен</span>'}</td></tr>"
        for r in rows
    )
    content = f"""
    <div class="card">
      <div class="card-title">📋 Тарифные планы</div>
      <table>
        <thead><tr><th>ID</th><th>Название</th><th>Комиссия %</th><th>Мин. комиссия</th><th>Лимит / день</th><th>Статус</th></tr></thead>
        <tbody>{table_rows}</tbody>
      </table>
    </div>"""
    return render_page(content)


# ═══════════════════════════════════════════════════════════════
# ОТЧЁТЫ — 3 аналитических запроса + дополнительные
# ═══════════════════════════════════════════════════════════════
@app.route("/reports")
def reports():
    with get_conn() as conn:
        # Запрос 1: клиент с наибольшим объёмом переводов в этом году
        q1 = conn.execute("""
            SELECT c.id, c.full_name, c.email, SUM(t.amount) AS total_sent
            FROM transactions t
            JOIN accounts a ON a.id = t.from_account_id
            JOIN clients c  ON c.id = a.client_id
            WHERE t.type='transfer' AND t.status='completed'
              AND strftime('%Y', t.created_at) = strftime('%Y','now')
            GROUP BY c.id ORDER BY total_sent DESC LIMIT 1
        """).fetchone()

        # Запрос 2: транзакции за сегодня
        q2 = conn.execute("""
            SELECT t.id, t.type, t.amount, t.status, t.description, t.created_at,
                   fa.account_no AS from_acc, ta.account_no AS to_acc
            FROM transactions t
            LEFT JOIN accounts fa ON fa.id=t.from_account_id
            LEFT JOIN accounts ta ON ta.id=t.to_account_id
            WHERE date(t.created_at) = date('now') ORDER BY t.created_at DESC
        """).fetchall()

        # Запрос 3: самый популярный тариф
        q3 = conn.execute("""
            SELECT tr.id, tr.name, tr.transfer_fee_pct, tr.min_fee, tr.max_daily_limit,
                   COUNT(t.id) AS usage_count
            FROM transactions t
            JOIN tariffs tr ON tr.id = t.tariff_id
            WHERE strftime('%Y-%m', t.created_at) = strftime('%Y-%m','now')
            GROUP BY tr.id ORDER BY usage_count DESC LIMIT 1
        """).fetchone()

        # Топ-5 счетов
        top5 = conn.execute(
            "SELECT a.account_no,c.full_name,a.currency,a.balance "
            "FROM accounts a JOIN clients c ON c.id=a.client_id "
            "WHERE a.is_active=1 ORDER BY a.balance DESC LIMIT 5"
        ).fetchall()

        # Статистика по типам
        tx_stats = conn.execute(
            "SELECT type,COUNT(*) AS cnt,COALESCE(SUM(amount),0) AS total FROM transactions GROUP BY type"
        ).fetchall()

    medals = ["🥇","🥈","🥉","4️⃣","5️⃣"]
    top5_rows = "".join(
        f"<tr><td>{medals[i]}</td><td><b>{r['full_name']}</b></td>"
        f"<td><code>{r['account_no']}</code></td>"
        f"<td style='text-align:right'><b>{r['balance']:,.2f} {r['currency']}</b></td></tr>"
        for i, r in enumerate(top5)
    )

    q2_rows = "".join(
        f"<tr><td>{r['id']}</td><td>{badge(r['type'])}</td>"
        f"<td>{r['from_acc'] or '—'} → {r['to_acc'] or '—'}</td>"
        f"<td style='text-align:right'><b>{r['amount']:,.2f}</b></td>"
        f"<td>{badge(r['status'])}</td><td>{r['description'] or '—'}</td></tr>"
        for r in q2
    ) or "<tr><td colspan='6' style='text-align:center;color:var(--muted)'>Транзакций за сегодня нет</td></tr>"

    stat_rows = "".join(
        f"<tr><td>{badge(r['type'])}</td><td style='text-align:right'>{r['cnt']}</td>"
        f"<td style='text-align:right'><b>{r['total']:,.2f} ₽</b></td></tr>"
        for r in tx_stats
    )

    q1_html = f"""
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px">
        <div class="stat"><div class="val" style="font-size:18px">{q1['full_name'] if q1 else '—'}</div><div class="lbl">ФИО клиента</div></div>
        <div class="stat"><div class="val" style="font-size:18px">{q1['email'] if q1 else '—'}</div><div class="lbl">Email</div></div>
        <div class="stat"><div class="val">{f"{q1['total_sent']:,.2f} ₽" if q1 else '—'}</div><div class="lbl">💸 Переведено за год</div></div>
      </div>""" if q1 else '<p style="color:var(--muted)">Нет данных за текущий год</p>'

    q3_html = f"""
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px">
        <div class="stat"><div class="val" style="font-size:18px">{q3['name']}</div><div class="lbl">Тариф</div></div>
        <div class="stat"><div class="val">{q3['usage_count']}</div><div class="lbl">Использований</div></div>
        <div class="stat"><div class="val">{q3['transfer_fee_pct']}%</div><div class="lbl">Комиссия (мин. {q3['min_fee']} ₽)</div></div>
        <div class="stat"><div class="val">{q3['max_daily_limit']:,.0f}</div><div class="lbl">Лимит / день (₽)</div></div>
      </div>""" if q3 else '<p style="color:var(--muted)">Нет данных за текущий месяц</p>'

    content = f"""
    <div class="card">
      <div class="card-title">🏆 Запрос 1: Клиент с наибольшим объёмом переводов в этом году</div>
      {q1_html}
    </div>

    <div class="card">
      <div class="card-title">📅 Запрос 2: Все транзакции за сегодня ({len(q2)} шт.)</div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>ID</th><th>Тип</th><th>Счета</th><th style="text-align:right">Сумма</th><th>Статус</th><th>Описание</th></tr></thead>
          <tbody>{q2_rows}</tbody>
        </table>
      </div>
    </div>

    <div class="card">
      <div class="card-title">⭐ Запрос 3: Самый популярный тариф в этом месяце</div>
      {q3_html}
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:22px">
      <div class="card">
        <div class="card-title">🏅 Топ-5 счетов по балансу</div>
        <table>
          <thead><tr><th>#</th><th>Клиент</th><th>Счёт</th><th style="text-align:right">Баланс</th></tr></thead>
          <tbody>{top5_rows}</tbody>
        </table>
      </div>
      <div class="card">
        <div class="card-title">📊 Статистика по типам транзакций</div>
        <table>
          <thead><tr><th>Тип</th><th style="text-align:right">Кол-во</th><th style="text-align:right">Оборот</th></tr></thead>
          <tbody>{stat_rows}</tbody>
        </table>
      </div>
    </div>
    """
    return render_page(content)


# ═══════════════════════════════════════════════════════════════
# ЖУРНАЛ СОБЫТИЙ
# ═══════════════════════════════════════════════════════════════
@app.route("/log")
def syslog():
    with get_conn() as conn:
        rows = conn.execute("SELECT event_type,message,created_at FROM system_log ORDER BY id DESC LIMIT 30").fetchall()
    table_rows = "".join(
        f"<tr><td><code style='background:#e3f2fd;padding:2px 6px;border-radius:4px'>{r['event_type']}</code></td>"
        f"<td>{r['message']}</td><td>{r['created_at']}</td></tr>"
        for r in rows
    )
    content = f"""
    <div class="card">
      <div class="card-title">📜 Журнал системных событий (последние 30)</div>
      <table>
        <thead><tr><th>Событие</th><th>Описание</th><th>Дата/время</th></tr></thead>
        <tbody>{table_rows}</tbody>
      </table>
    </div>"""
    return render_page(content)


if __name__ == "__main__":
    init_db()
    print("Версия 2 запущена: http://127.0.0.1:5002")
    app.run(debug=True, port=5002)
