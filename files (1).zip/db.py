#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Общий модуль базы данных для системы электронных платежей
"""
import sqlite3
import os

DB_NAME = os.path.join(os.path.dirname(__file__), "payments_system.db")


def get_conn():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def log_event(event_type: str, message: str):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO system_log(event_type,message) VALUES(?,?)",
            (event_type, message)
        )


def init_db():
    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()

    cur.executescript("""
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS clients (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name   TEXT    NOT NULL,
        email       TEXT    UNIQUE NOT NULL,
        phone       TEXT,
        status      TEXT    DEFAULT 'active' CHECK(status IN ('active','blocked','pending')),
        created_at  TEXT    DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS accounts (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        client_id   INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
        account_no  TEXT    UNIQUE NOT NULL,
        currency    TEXT    DEFAULT 'RUB' CHECK(currency IN ('RUB','USD','EUR')),
        balance     REAL    DEFAULT 0.00,
        is_active   INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS tariffs (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        name             TEXT    NOT NULL,
        transfer_fee_pct REAL    DEFAULT 0.0,
        min_fee          REAL    DEFAULT 0.0,
        max_daily_limit  REAL    DEFAULT 100000.0,
        is_active        INTEGER DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS transactions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        from_account_id INTEGER REFERENCES accounts(id),
        to_account_id   INTEGER REFERENCES accounts(id),
        tariff_id       INTEGER REFERENCES tariffs(id),
        amount          REAL    NOT NULL CHECK(amount > 0),
        type            TEXT    NOT NULL CHECK(type IN ('transfer','deposit','withdrawal','fee')),
        status          TEXT    DEFAULT 'pending' CHECK(status IN ('pending','completed','failed','reversed')),
        description     TEXT,
        created_at      TEXT    DEFAULT (datetime('now','localtime'))
    );

    CREATE TABLE IF NOT EXISTS system_log (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        event_type  TEXT    NOT NULL,
        message     TEXT,
        created_at  TEXT    DEFAULT (datetime('now','localtime'))
    );
    """)

    cur.execute("SELECT COUNT(*) FROM clients")
    if cur.fetchone()[0] == 0:
        _seed_demo_data(cur)

    conn.commit()
    conn.close()


def _seed_demo_data(cur):
    clients = [
        ("Иванов Иван Иванович",        "ivanov@mail.ru",   "+7-900-100-0001"),
        ("Петрова Мария Сергеевна",      "petrova@mail.ru",  "+7-900-100-0002"),
        ("Смирнов Алексей Борисович",    "smirnov@mail.ru",  "+7-900-100-0003"),
    ]
    cur.executemany(
        "INSERT INTO clients(full_name,email,phone) VALUES(?,?,?)", clients
    )

    accounts = [
        (1, "ACC-0001-RUB", "RUB", 15000.00),
        (1, "ACC-0002-USD", "USD",   250.00),
        (2, "ACC-0003-RUB", "RUB",  7500.50),
        (3, "ACC-0004-RUB", "RUB", 32000.00),
    ]
    cur.executemany(
        "INSERT INTO accounts(client_id,account_no,currency,balance) VALUES(?,?,?,?)",
        accounts
    )

    tariffs = [
        ("Стандарт",  0.5,  10.0,    50000.0),
        ("Бизнес",    0.2,   5.0,   500000.0),
        ("Премиум",   0.0,   0.0,  9999999.0),
    ]
    cur.executemany(
        "INSERT INTO tariffs(name,transfer_fee_pct,min_fee,max_daily_limit) VALUES(?,?,?,?)",
        tariffs
    )

    transactions = [
        (1, 3, 1, 2000.00, "transfer",   "completed", "Перевод Петровой"),
        (3, 1, 1,  500.00, "transfer",   "completed", "Возврат"),
        (4, 2, 2, 1000.00, "transfer",   "failed",    "Превышен лимит"),
        (None, 1, None, 5000.00, "deposit",    "completed", "Пополнение счёта"),
        (1, None, None,  300.00, "withdrawal", "completed", "Снятие наличных"),
    ]
    cur.executemany(
        "INSERT INTO transactions(from_account_id,to_account_id,tariff_id,amount,type,status,description)"
        " VALUES(?,?,?,?,?,?,?)",
        transactions
    )

    cur.execute(
        "INSERT INTO system_log(event_type,message) VALUES('INIT','База данных инициализирована с демо-данными')"
    )
