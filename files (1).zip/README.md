# 💳 Система электронных платежей — Веб-приложение Flask

Веб-версия терминального приложения `payments_app.py`.  
Разработано в рамках курсовой работы по ПМ.06 «Сопровождение информационных систем».

---

## Структура проекта

```
payments_web/
├── db.py              # Общий модуль БД (SQLite), инициализация, демо-данные
├── payments_system.db # База данных (создаётся автоматически)
├── v1/
│   └── app_v1.py      # Версия 1 — базовая (порт 5001)
└── v2/
    └── app_v2.py      # Версия 2 — расширенная (порт 5002)
```

---

## Запуск

### Установка зависимостей
```bash
pip install flask
```

### Версия 1 (базовая)
```bash
cd v1
python3 app_v1.py
# Открыть: http://127.0.0.1:5001
```

### Версия 2 (расширенная)
```bash
cd v2
python3 app_v2.py
# Открыть: http://127.0.0.1:5002
```

---

## Версия 1 — базовая

**Описание:** Минималистичное одностраничное Flask-приложение. Весь HTML-код
хранится непосредственно в файле `app_v1.py` в виде строк Python (без
отдельных файлов шаблонов).

**Возможности:**
- Просмотр клиентов, счетов, транзакций
- Добавление клиента, смена статуса
- Открытие счёта, пополнение
- Перевод и снятие средств
- Три аналитических запроса + дополнительные отчёты

---

## Версия 2 — расширенная

**Описание:** Полноценное Flask-приложение с современным UI: боковое меню,
карточки, адаптивная сетка, цветные бейджи, прогресс-бар, поиск и фильтры.

**Дополнительные возможности по сравнению с версией 1:**
- Боковое навигационное меню (sidebar)
- Поиск клиентов по имени / email
- Фильтрация транзакций по типу и статусу
- Поддержка тарифов при переводе (расчёт комиссии)
- Закрытие счётов
- Журнал системных событий
- Страница тарифных планов
- Прогресс-бар успешности транзакций

---

## База данных

Общая для обеих версий (`payments_system.db`).

**Таблицы:**
| Таблица        | Описание                        |
|----------------|---------------------------------|
| `clients`      | Клиенты системы                 |
| `accounts`     | Банковские счета                |
| `transactions` | Транзакции (переводы, депозиты) |
| `tariffs`      | Тарифные планы                  |
| `system_log`   | Журнал системных событий        |

**Демо-данные** создаются автоматически при первом запуске.

---

## Аналитические запросы (SQL)

### Запрос 1: Клиент с наибольшим объёмом переводов в текущем году
```sql
SELECT c.id, c.full_name, c.email, SUM(t.amount) AS total_sent
FROM transactions t
JOIN accounts a ON a.id = t.from_account_id
JOIN clients c  ON c.id = a.client_id
WHERE t.type = 'transfer'
  AND t.status = 'completed'
  AND strftime('%Y', t.created_at) = strftime('%Y', 'now')
GROUP BY c.id
ORDER BY total_sent DESC
LIMIT 1;
```

### Запрос 2: Все транзакции за сегодня
```sql
SELECT t.id, t.type, t.amount, t.status, t.description, t.created_at,
       fa.account_no AS from_acc, ta.account_no AS to_acc
FROM transactions t
LEFT JOIN accounts fa ON fa.id = t.from_account_id
LEFT JOIN accounts ta ON ta.id = t.to_account_id
WHERE date(t.created_at) = date('now')
ORDER BY t.created_at DESC;
```

### Запрос 3: Самый популярный тариф в текущем месяце
```sql
SELECT tr.name, tr.transfer_fee_pct, tr.min_fee, tr.max_daily_limit,
       COUNT(t.id) AS usage_count
FROM transactions t
JOIN tariffs tr ON tr.id = t.tariff_id
WHERE strftime('%Y-%m', t.created_at) = strftime('%Y-%m', 'now')
GROUP BY tr.id
ORDER BY usage_count DESC
LIMIT 1;
```
